import app from './app.js';
import sequelize from './src/config/database.js';
import applyAssociations from './src/models/associations.js';

async function main() {
  try {
    // Verificar conexión a la base de datos PostgreSQL
    await sequelize.authenticate();
    console.log(' Conectado a PostgreSQL correctamente');
    applyAssociations(sequelize)

    // Verificar si se ejecuta con el parámetro -init
    const init = process.argv[2];


    // Sincronizar los modelos con la base de datos
    if (init) {
      await sequelize.sync({ force: true }); // Borra y vuelve a crear las tablas
      console.log(' Base de datos sincronizada (force:true)');
    } else {
      await sequelize.sync({ force: false }); // Mantiene los datos existentes
      console.log(' Base de datos sincronizada');
    }

    // Iniciar servidor Express
    app.listen(3001, () => {
      console.log(' Servidor corriendo en puerto 3001');
    });

  } catch (error) {
    console.error('Error al conectar o iniciar el servidor:', error);
  }
}

main();


