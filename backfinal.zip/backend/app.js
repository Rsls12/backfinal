import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';

import productoRoutes from './src/routes/producto.js'
import CarritoDeCompraRouter from './src/routes/CarritoDeCompra.js'
import ItemDeCarritoRouter from './src/routes/ItemDeCarrito.js'
import ItemDeLaOrdenRouter from './src/routes/ItemDeLaOrden.js'
import OrdenRouter from './src/routes/Orden.js'
import UsuarioRouter from './src/routes/Usuario.js'


const app = express();
app.use(cors());
app.use((req, res, next) => {
    console.log('Middleware de Express.json ejecutándose...');
    console.log('El Content-Type de la solicitud es:', req.headers['content-type']);
    next();
});
app.use(express.json());

// Asegúrate que esta ruta esté ANTES de cualquier `express.static`
app.use('/producto', productoRoutes);
app.use('/api', CarritoDeCompraRouter);
app.use('/itemcarrito', ItemDeCarritoRouter);
app.use('/itemorden', ItemDeLaOrdenRouter);
app.use('/api/orden', OrdenRouter);
app.use('/usuario', UsuarioRouter);
export default app;