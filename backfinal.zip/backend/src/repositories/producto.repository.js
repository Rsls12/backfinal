import Producto from '../models/producto.js';

export const findAllProductos = () => Producto.findAll();

export const createProducto = (data) => Producto.create(data);
