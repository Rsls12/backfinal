import model from '../models/Usuario.js'
import RepositoryBase from './base.js'

const repository = new RepositoryBase(model);

export default repository;