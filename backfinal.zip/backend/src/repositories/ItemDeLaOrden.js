import model from '../models/ItemDeLaOrden.js'
import RepositoryBase from './base.js'

const repository = new RepositoryBase(model);

export default repository;