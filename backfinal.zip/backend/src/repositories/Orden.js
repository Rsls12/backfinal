import model from '../models/Orden.js'
import RepositoryBase from './base.js'

const repository = new RepositoryBase(model);

export default repository;