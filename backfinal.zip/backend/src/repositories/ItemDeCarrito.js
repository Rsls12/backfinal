import model from '../models/ItemDeCarrito.js'
import RepositoryBase from './base.js'

const repository = new RepositoryBase(model);

export default repository;