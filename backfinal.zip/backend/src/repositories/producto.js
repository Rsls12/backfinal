import model from '../models/producto.js'
import RepositoryBase from './base.js'

const repository = new RepositoryBase(model);

export default repository;