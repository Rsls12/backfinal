import model from '../models/CarritoDeCompra.js'
import RepositoryBase from './base.js'

const repository = new RepositoryBase(model);

export default repository;