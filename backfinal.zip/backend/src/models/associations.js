import Usuario from './Usuario.js';
import Orden from './Orden.js';
import CarritoDeCompra from './CarritoDeCompra.js';
import ItemDeCarrito from './ItemDeCarrito.js';
import ItemDeLaOrden from './ItemDeLaOrden.js';
import Producto from './producto.js';

export default function applyAssociations() {
  // Asociación entre Usuario y CarritoDeCompra
  Usuario.hasMany(CarritoDeCompra, { foreignKey: 'idusuario' });
  CarritoDeCompra.belongsTo(Usuario, { foreignKey: 'idusuario' });

  // Asociación entre Usuario y Orden
  Usuario.hasMany(Orden, { foreignKey: 'idusuario' });
  Orden.belongsTo(Usuario, { foreignKey: 'idusuario' });

  // Asociación entre CarritoDeCompra y ItemDeCarrito
  CarritoDeCompra.hasMany(ItemDeCarrito, { foreignKey: 'idcarrito' });
  ItemDeCarrito.belongsTo(CarritoDeCompra, { foreignKey: 'idcarrito' });

  // Asociación entre Orden y ItemDeLaOrden
  Orden.hasMany(ItemDeLaOrden, { foreignKey: 'idorden' });
  ItemDeLaOrden.belongsTo(Orden, { foreignKey: 'idorden' });

  // Asociación entre Producto y los ítems (en Carrito y en la Orden)
  Producto.hasMany(ItemDeCarrito, { foreignKey: 'idproducto' });
  Producto.hasMany(ItemDeLaOrden, { foreignKey: 'idproducto' });
}