import sequelize from '../config/database.js';
import { DataTypes } from 'sequelize';

const ItemDeCarrito = sequelize.define('itemdecarrito', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  idcarrito: {
    type: DataTypes.INTEGER,
    allowNull: false,
    field: 'idcarrito',
  },
  idproducto: {
    type: DataTypes.INTEGER,
    allowNull: false,
    field: 'idproducto',
  },
  cantidad: {
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: 1  // Valor por defecto si no se pasa cantidad
  },
  precio: {
    type: DataTypes.DECIMAL,
    allowNull: false
  }
});

// Definir las asociaciones
ItemDeCarrito.associate = (models) => {
  // Un item de carrito pertenece a un carrito de compra
  ItemDeCarrito.belongsTo(models.CarritoDeCompra, { foreignKey: 'idcarrito' });

  // Un item de carrito pertenece a un producto
  ItemDeCarrito.belongsTo(models.Producto, { foreignKey: 'idproducto' });
};

export default ItemDeCarrito;
