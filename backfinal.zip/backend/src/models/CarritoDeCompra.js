import sequelize from '../config/database.js';
import { DataTypes } from 'sequelize';

const CarritoDeCompra = sequelize.define('carritodecompra', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  idusuario: {
    type: DataTypes.INTEGER,
    allowNull: false,
    field: 'idusuario',
  }
});

// Definir las asociaciones
CarritoDeCompra.associate = (models) => {
  // Un carrito de compra pertenece a un usuario
  CarritoDeCompra.belongsTo(models.Usuario, { foreignKey: 'idusuario' });

    // Un carrito de compra tiene muchos items de carrito
  CarritoDeCompra.hasMany(models.ItemDeCarrito, { foreignKey: 'idcarrito' });
};

export default CarritoDeCompra;
