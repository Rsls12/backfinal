import { Sequelize, DataTypes } from 'sequelize';
import sequelize from '../config/database.js';
import defineProducto from '../models/producto.js';

const Producto = defineProducto(sequelize, DataTypes);

export { sequelize, Producto };
