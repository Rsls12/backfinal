import sequelize from '../config/database.js';
import { DataTypes } from 'sequelize';

const Orden = sequelize.define('orden', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  idusuario: {
    type: DataTypes.INTEGER,
    allowNull: false,
    field: 'idusuario',
  },
  fecha: {
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: DataTypes.NOW
  },
  total: {
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: 0,
  },
  subtotal: {
    type: DataTypes.INTEGER,
    allowNull: false,
    field: 'subtotal',
    defaultValue: 0,
    
  },
  metododeentrega: {
    type: DataTypes.STRING,
    allowNull: false,
    field: 'metododeentrega',
  },
  nrotarjeta: {
    type: DataTypes.STRING,
    allowNull: false,
    field: 'nrotarjeta',
  },
  tipotarjeta: {
    type: DataTypes.STRING,
    allowNull: false,
    field: 'tipotarjeta',
  }
});
Orden.associate = (models) => {
  // Relación con 'Usuario'
  Orden.belongsTo(models.Usuario, { foreignKey: 'idusuario', targetKey: 'id' });
  // Relación con 'ItemDeLaOrden'
  Orden.hasMany(models.ItemDeLaOrden, { foreignKey: 'idorden', sourceKey: 'id' });
};
export default Orden;
