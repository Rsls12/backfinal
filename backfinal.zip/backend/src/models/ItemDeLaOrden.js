import sequelize from '../config/database.js';
import { DataTypes } from 'sequelize';

const ItemDeLaOrden = sequelize.define('itemdelaorden', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  idorden: {
    type: DataTypes.INTEGER,
    allowNull: false,
    field: 'idorden',
  },
  idproducto: {
    type: DataTypes.INTEGER,
    allowNull: false,
    field: 'idproducto',
  }
});
ItemDeLaOrden.associate = (models) => {
  // Relación con 'Orden'
  ItemDeLaOrden.belongsTo(models.Orden, { foreignKey: 'idorden', targetKey: 'id' });
  // Relación con 'Producto'
  ItemDeLaOrden.belongsTo(models.Producto, { foreignKey: 'idproducto', targetKey: 'id' });
};
export default ItemDeLaOrden;
