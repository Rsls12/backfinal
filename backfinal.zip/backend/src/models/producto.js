import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

const Producto = sequelize.define('producto', {
  nombre: DataTypes.STRING,
  descripcion: DataTypes.STRING,
  marca: DataTypes.STRING,
  stock: DataTypes.INTEGER,
  precio: DataTypes.DECIMAL,
  categoria: DataTypes.STRING,
  imagen: DataTypes.TEXT
});

export default Producto;