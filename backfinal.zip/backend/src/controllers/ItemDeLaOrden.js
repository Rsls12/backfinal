import repository from '../repositories/ItemDeLaOrden.js'

const findAll = async (req, res) => {

    const result = await repository.findAll();

    return sendResults(result,res);
}

const findOne = async (req, res) => {
    const id = req.params.id;
    const result = await repository.findOne(id);

    return sendResults(result,res);
}

const create = async (req, res) => {
  const { idorden, idproducto, cantidad } = req.body;

  try {
    // Verifica que la orden exista
    const ordenExistente = await repository.findOne(idorden);

    if (!ordenExistente) {
      return res.status(404).json({ message: 'Orden no encontrada' });
    }

    // Crea el ítem de la orden
    const result = await repository.create({ idorden, idproducto, cantidad });

    return sendResults(result, res);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Error al crear el ítem de la orden' });
  }
}


const update = async (req, res) => {
    const payload = req.body;

    const result = await repository.update(payload);

    return sendResults(result,res)
}

const remove = async (req, res) => {
    const id = req.params.id;
    const result = await repository.remove(id);

    return sendResults(result,res);
}
const findItemsByOrden = async (req, res) => {
  const { idOrden } = req.params;

  try {
    const items = await repository.findAll({
      where: { idorden: idOrden }
    });

    return sendResults(items, res);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Error al obtener los ítems de la orden" });
  }
};


const sendResults = (result, res) => {
    if (result)
        return res.status(200).json(result);
    else
        return res.status(500).json({ message: "Ha ocurrido un error!"})
}

const controller = { findAll, findOne, create, update, remove, findItemsByOrden }

export default controller;