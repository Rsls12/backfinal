import repository from '../repositories/Usuario.js'


const findAll = async (req, res) => {
    const result = await repository.findAll();
    return sendResults(result, res);
}


const findOne = async (req, res) => {
    const id = req.params.id;
    const result = await repository.findOne(id);
    return sendResults(result, res);
}


const create = async (req, res) => {
    const payload = req.body;
    const result = await repository.create(payload);
    return sendResults(result, res);
}

const update = async (req, res) => {
    const payload = req.body;
    const result = await repository.update(payload);
    return sendResults(result, res);
}


const remove = async (req, res) => {
    const id = req.params.id;
    const result = await repository.remove(id);
    return sendResults(result, res);
}


const login = async (req, res) => {
    const { email, password } = req.body;
    const user = await repository.findByEmail(email);

    if (!user) {
        return res.status(404).json({ message: "Usuario no encontrado" });
    }

    if (user.password !== password) {
        return res.status(401).json({ message: "Contraseña incorrecta" });
    }

    return res.status(200).json({ message: "Login exitoso", usuario: user });
};

const register = async (req, res) => {
    const { email, password, nombre } = req.body;

    const existingUser = await repository.findByEmail(email);
    if (existingUser) {
        return res.status(400).json({ message: "El correo ya está registrado" });
    }

    const payload = { email, password, nombre };
    const result = await repository.create(payload);
    return sendResults(result, res);
};

const sendResults = (result, res) => {
    if (result)
        return res.status(200).json(result);
    else
        return res.status(500).json({ message: "Ha ocurrido un error!" });
}

const controller = { findAll, findOne, create, update, remove, login, register }

export default controller;