import Producto from '../models/producto.js';

export const findAll = async (req, res) => {
  try {
    const productos = await Producto.findAll();
    res.json(productos);
  } catch (err) {
    res.status(500).json({ error: 'Error al obtener productos' });
  }
};

export const findOne = async (req, res) => {
  try {
    const producto = await Producto.findByPk(req.params.id);
    if (!producto) return res.status(404).json({ error: 'No encontrado' });
    res.json(producto);
  } catch (err) {
    res.status(500).json({ error: 'Error al buscar producto' });
  }
};

export const create = async (req, res) => {
  try {
    const nuevo = await Producto.create(req.body);
    res.status(201).json(nuevo);
  } catch (err) {
    res.status(400).json({ error: 'Error al crear producto' });
  }
};

export const update = async (req, res) => {
  try {
    const actualizado = await Producto.update(req.body, {
      where: { id: req.params.id }
    });
    res.json({ mensaje: 'Producto actualizado', actualizado });
  } catch (err) {
    res.status(400).json({ error: 'Error al actualizar producto' });
  }
};

export const remove = async (req, res) => {
  try {
    const eliminado = await Producto.destroy({ where: { id: req.params.id } });
    res.json({ mensaje: 'Producto eliminado', eliminado });
  } catch (err) {
    res.status(400).json({ error: 'Error al eliminar producto' });
  }
};
