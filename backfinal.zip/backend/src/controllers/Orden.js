import repository from '../repositories/Orden.js'
import CarritoDeCompra from '../models/CarritoDeCompra.js'; 
import ItemDeCarrito from '../models/ItemDeCarrito.js'; 
import Orden from '../models/Orden.js';
import ItemDeLaOrden from '../models/ItemDeLaOrden.js';

const findAll = async (req, res) => {

    const result = await repository.findAll();

    return sendResults(result,res);
}

const findOne = async (req, res) => {
    const id = req.params.id;
    const result = await repository.findOne(id);

    return sendResults(result,res);
}

const create = async (req, res) => {
  const { idusuario, metododeentrega, nrotarjeta, tipotarjeta } = req.body;

  try {
    // Verificar que el carrito existe
    const carrito = await CarritoDeCompra.findOne({ where: { idusuario } });

    if (!carrito) {
      return res.status(404).json({ message: 'Carrito no encontrado' });
    }

    // Crear la orden
    const orden = await repository.create({
      idusuario: idusuario,
      total: carrito.total,
      subtotal: carrito.total,
      metododeentrega: metododeentrega,
      nrotarjeta: nrotarjeta,
      tipotarjeta: tipotarjeta
    });

    // Asociar los ítems del carrito a la orden
    const itemsDelCarrito = await ItemDeCarrito.findAll({ where: { idcarrito: carrito.id } });

    for (let item of itemsDelCarrito) {
      await ItemDeLaOrden.create({
        idorden: orden.id,
        idproducto: item.idproducto,
        cantidad: item.cantidad
      });
    }

    // Limpiar el carrito después de crear la orden
    await ItemDeCarrito.destroy({ where: { idcarrito: carrito.id } });

    return sendResults(orden, res);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Error al crear la orden' });
  }
};


const update = async (req, res) => {
    const payload = req.body;

    const result = await repository.update(payload);

    return sendResults(result,res)
}

const remove = async (req, res) => {
    const id = req.params.id;
    const result = await repository.remove(id);

    return sendResults(result,res);
}
const convertirCarritoEnOrden = async (req, res) => {
  const { idusuario, metododeentrega, nrotarjeta, tipotarjeta } = req.body;

  try {
    // Verificar si el carrito existe para el usuario
    const carrito = await CarritoDeCompra.findOne({ where: { idusuario } });

    if (!carrito) {
      return res.status(404).json({ message: 'Carrito no encontrado' });
    }
    console.log('Carrito encontrado:', carrito.toJSON()); // Muestra todo el objeto carrito
    console.log('Valor de carrito.total:', carrito.total); // Muestra solo el total

    // Crear la orden
    const orden = await Orden.create({
      idusuario: idusuario,
      total: carrito.total,
      subtotal: carrito.total,
      metododeentrega: metododeentrega,
      nrotarjeta: nrotarjeta,
      tipotarjeta: tipotarjeta
    });

    // Copiar los ítems del carrito a la orden
    const itemsDelCarrito = await ItemDeCarrito.findAll({ where: { idcarrito: carrito.id } });

    for (let item of itemsDelCarrito) {
      await ItemDeLaOrden.create({
        idorden: orden.id,
        idproducto: item.idproducto,
        cantidad: item.cantidad
      });
    }

    // Limpiar el carrito después de crear la orden
    await ItemDeCarrito.destroy({ where: { idcarrito: carrito.id } });

    return res.status(201).json(orden);
  } catch (error) {
    console.error('Error al convertir carrito en orden:', error);
    return res.status(500).json({ message: 'Error al convertir el carrito en orden' });
  }
};

const sendResults = (result, res) => {
    if (result)
        return res.status(200).json(result);
    else
        return res.status(500).json({ message: "Ha ocurrido un error!"})
}

const controller = { findAll, findOne, create, update, remove,convertirCarritoEnOrden };
export default controller;