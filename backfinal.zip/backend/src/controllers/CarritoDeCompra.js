import CarritoDeCompra from '../models/CarritoDeCompra.js';
import ItemDeCarrito from '../models/ItemDeCarrito.js';
import Producto from '../models/producto.js'; 
// Agregar producto al carrito
export const agregarAlCarrito = async (req, res) => {
  const { idusuario, idproducto, cantidad } = req.body;

  // Validación de parámetros
  if (!idusuario || !idproducto || !cantidad) {
    return res.status(400).json({ error: 'Faltan datos en la solicitud' });
  }

  try {
    // Verificar si el carrito ya existe para este usuario
    let carrito = await CarritoDeCompra.findOne({
      where: { idusuario },
    });

    if (!carrito) {
      // Si no existe, crear un nuevo carrito
      carrito = await CarritoDeCompra.create({
        idusuario,
        total: 0,  // Inicialmente el total es 0
      });
    }

    // Verificar si el producto ya está en el carrito
    let itemExistente = await ItemDeCarrito.findOne({
      where: {
        idcarrito: carrito.id,
        idproducto,
      },
    });

    if (itemExistente) {
      // Si el producto ya está en el carrito, actualizar la cantidad
      itemExistente.cantidad += cantidad;  // Aumentamos la cantidad
      await itemExistente.save();
    } else {
      // Si el producto no está en el carrito, agregarlo
      const producto = await Producto.findByPk(idproducto);

      if (!producto) {
        return res.status(404).json({ error: 'Producto no encontrado' });
      }

      await ItemDeCarrito.create({
        idcarrito: carrito.id,
        idproducto,
        cantidad,
        precio: producto.precio,
      });
    }

    // Actualizar el total del carrito
    const totalCarrito = await ItemDeCarrito.sum('precio', {
      where: { idcarrito: carrito.id },
    });

    if (totalCarrito === null) {
      return res.status(500).json({ error: 'Error al calcular el total del carrito' });
    }

    carrito.total = totalCarrito;
    await carrito.save();

    // Responder con el carrito actualizado
    res.status(200).json(carrito);
  } catch (error) {
    console.error('Error al agregar al carrito:', error);
    res.status(500).json({ error: 'Error en el servidor' });
  }
};