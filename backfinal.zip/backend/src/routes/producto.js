import express from 'express';
import Producto from '../models/producto.js'; // ✅ corregido

const router = express.Router();

router.get('/', async (req, res) => {
  try {
    const productos = await Producto.findAll();
    res.json(productos);
  } catch (err) {
    console.error('Error al obtener productos:', err);
    res.status(500).json({ error: 'Error del servidor' });
  }
});

export default router;