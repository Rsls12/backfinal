import express from 'express'

import controller from '../controllers/Orden.js'

const router = express.Router();

// Rutas CRUD estándar para Orden
router.get('/', controller.findAll);
router.get('/:id', controller.findOne);

// Ruta para crear una orden (convirtiendo un carrito en orden)
router.post('/convertir-carrito', controller.create);

// Rutas de actualización y eliminación
router.put('/', controller.update);
router.delete('/:id', controller.remove);

export default router;