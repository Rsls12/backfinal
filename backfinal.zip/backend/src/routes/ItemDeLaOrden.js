import express from 'express'

import controller from '../controllers/ItemDeLaOrden.js'

const router = express.Router();

// Obtener todos los ítems de la orden
router.get('/orden/:idorden', controller.findItemsByOrden);

// Operaciones CRUD estándar para ItemDeLaOrden
router.get('/', controller.findAll);
router.get('/:id', controller.findOne);
router.post('/', controller.create);
router.put('/', controller.update);
router.delete('/:id', controller.remove);

export default router;