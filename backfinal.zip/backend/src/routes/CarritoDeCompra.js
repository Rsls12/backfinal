import express from 'express'

import {agregarAlCarrito} from '../controllers/CarritoDeCompra.js'

const router = express.Router();

router.post('/carrito/agregar', agregarAlCarrito);

export default router;