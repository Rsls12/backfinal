// src/config/database.js
import { Sequelize } from 'sequelize';

const sequelize = new Sequelize(
  'productodb',     // nombre de la base de datos
  'postgres',       // usuario
  'Pruebas0234.@GT', // ← reemplaza con tu contraseña real
  {
    host: 'localhost',
    dialect: 'postgres',
    port: 5432,
    logging: false
  }
);

export default sequelize;